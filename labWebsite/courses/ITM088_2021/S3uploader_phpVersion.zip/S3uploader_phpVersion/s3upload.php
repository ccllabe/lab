<?php
####################usage############################
#php s3upload.php uploadfile objkey
#uploadfile 是要上傳的檔案 注意路徑
#objkey 是上傳至S3後的名字
#####################################################
require 'vendor/autoload.php';

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

if(count($argv) != 3 ){
    echo "Not enough parameter\n";
    exit(1);
}

if(isset($argv[1])){
    $file = $argv[1];
}

if(empty($file)){
    echo "No input File\n";
    exit(1);
}

if(!file_exists($file)){
    echo "The file is not exist\n";
    exit(1);
}

$bucket = 'cgu-cloud-system';
#$keyname = '*** Your Object Key ***';
$keyname = $argv[2];

$s3 = new S3Client([
    'version' => 'latest',
    'region'  => 'us-east-1'
]);

try {
    // Upload data.
    $result = $s3->putObject([
        'Bucket' => $bucket,
        'Key'    => $keyname,
        #'Content-Type' => 'image/jpeg',
        'Body' => file_get_contents($file),
        'ACL'    => 'public-read'
    ]);

    // Print the URL to the object.
    echo $result['ObjectURL'] . PHP_EOL;
} catch (S3Exception $e) {
    echo $e->getMessage() . PHP_EOL;
}
?>
